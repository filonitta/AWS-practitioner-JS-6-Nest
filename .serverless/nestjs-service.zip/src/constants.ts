export const JWT_CONFIG = {
  secret: 'secret',
  expiresIn: '12h'
}
